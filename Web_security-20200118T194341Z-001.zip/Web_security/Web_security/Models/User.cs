﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Web_security.Models
{
    public class User
    {
        [Required(ErrorMessage ="Username required",AllowEmptyStrings =false)]
        public string Username { get; set; }

        [Required(ErrorMessage ="Password is required",AllowEmptyStrings =false)]
        [DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        public string Password { get; set; }

        public bool RememberMe { get; set; }
    }
}