﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_security.Models;
using System.Web.Security;

namespace Web_security.Controllers
{
    public class MyaccountController : Controller
    {

        public ActionResult login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult login(User l , string ReturnUrl = "")
        {
            using (PSLEntities dc = new PSLEntities())
            {
                var user = dc.Logins.Where(a => a.User_name.Equals(l.Username) && a.Password.Equals(l.Password)).FirstOrDefault();
                if(user != null)
                {
                    FormsAuthentication.SetAuthCookie(user.User_name, l.RememberMe);

                    if (Url.IsLocalUrl(ReturnUrl))
                    {
                        return Redirect(ReturnUrl);
                    }
                    else
                    {
                        return RedirectToAction("Profile", "Home");
                    }
                }
            }
            ModelState.Remove("Password");
                return View();
        }

        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("index", "home");
        }
    }
}